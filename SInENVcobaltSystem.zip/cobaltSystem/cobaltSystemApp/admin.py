from django.contrib import admin
from .models import add_user
# Register your models here.
admin.site.register(add_user);
